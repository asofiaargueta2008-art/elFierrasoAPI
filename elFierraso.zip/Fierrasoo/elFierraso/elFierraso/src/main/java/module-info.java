module sv.elfierraso {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.net.http;
    requires com.google.gson;
    requires com.fasterxml.jackson.databind;
    requires javafx.graphics;

    opens sv.elfierraso.controller to javafx.fxml;
    opens sv.elfierraso.model to com.google.gson;
    exports sv.elfierraso.controller;
    exports sv.elfierraso.model;
    exports sv.elfierraso;
}

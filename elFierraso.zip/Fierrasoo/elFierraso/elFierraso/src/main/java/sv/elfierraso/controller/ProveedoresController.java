package sv.elfierraso.controller;

import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import sv.elfierraso.model.Proveedores;
import sv.elfierraso.service.ProveedorService;

import java.util.Objects;

public class ProveedoresController {

    @FXML private TableView<Proveedores> tabla;
    @FXML private TableColumn<Proveedores, String> colNombre;
    @FXML private TableColumn<Proveedores, Number> colTelefono;
    @FXML private TableColumn<Proveedores, String> colEmail;

    @FXML private TextField txtNombre;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtEmail;

    private final ProveedorService service = new ProveedorService();
    private final ObservableList<Proveedores> lista = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colNombre.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNombre()));
        colTelefono.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getTelefono()));
        colEmail.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getEmail()));

        tabla.setItems(lista);

        cargar();
    }

    @FXML
    private void cargar() {
        try {
            lista.setAll(service.getAll());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void agregar() {
        try {
            Proveedores p = new Proveedores();
            p.setNombre(txtNombre.getText());
            p.setTelefono(Integer.parseInt(txtTelefono.getText()));
            p.setEmail(txtEmail.getText());
            p.setUrlImagen("No");

            service.create(p);
            cargar();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void eliminar() {
        Proveedores seleccionado = tabla.getSelectionModel().getSelectedItem();
        if (seleccionado == null) return;

        try {
            service.delete(seleccionado.getIdProveedor());
            cargar();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

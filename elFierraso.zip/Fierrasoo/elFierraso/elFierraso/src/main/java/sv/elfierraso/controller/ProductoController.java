package sv.elfierraso.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import sv.elfierraso.model.Producto;
import sv.elfierraso.service.ProductoService;

import java.util.List;
import java.util.Objects;

public class ProductoController {

    @FXML private BorderPane root;

    @FXML private TableView<Producto> tabla;
    @FXML private TableColumn<Producto, String> colNombre;
    @FXML private TableColumn<Producto, Number> colPrecio;
    @FXML private TableColumn<Producto, Number> colStock;
    @FXML private TableColumn<Producto, Number> colProveedor;

    @FXML private TextField txtNombre;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtStock;
    @FXML private TextField txtProveedor;

    @FXML private ProgressIndicator loading;

    private final ProductoService service = new ProductoService();
    private final ObservableList<Producto> data = FXCollections.observableArrayList();

    private Producto seleccionado;

    @FXML
    public void initialize() {

        colNombre.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNombre()));
        colPrecio.setCellValueFactory(c -> new javafx.beans.property.SimpleDoubleProperty(c.getValue().getPrecio()));
        colStock.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getStock()));
        colProveedor.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getIdProveedor()));

        tabla.setItems(data);
        loading.setVisible(false);

        tabla.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n != null) {
                seleccionado = n;
                txtNombre.setText(n.getNombre());
                txtPrecio.setText(String.valueOf(n.getPrecio()));
                txtStock.setText(String.valueOf(n.getStock()));
                txtProveedor.setText(String.valueOf(n.getIdProveedor()));
            }
        });

        cargar();
    }

    private void cargar() {

        loading.setVisible(true);

        Task<List<Producto>> task = new Task<>() {
            @Override
            protected List<Producto> call() throws Exception {
                return service.getAll();
            }
        };

        task.setOnSucceeded(e -> {
            data.setAll(task.getValue());
            loading.setVisible(false);
        });

        task.setOnFailed(e -> {
            loading.setVisible(false);
            error(task.getException().getMessage());
        });

        new Thread(task).start();
    }

    @FXML
    private void agregar() {
        try {

            Producto p = new Producto();
            p.setNombre(txtNombre.getText());
            p.setPrecio(Double.parseDouble(txtPrecio.getText()));
            p.setStock(Integer.parseInt(txtStock.getText()));
            p.setIdProveedor(Integer.parseInt(txtProveedor.getText()));

            service.create(p);

            limpiar();
            cargar();

        } catch (Exception e) {
            error(e.getMessage());
        }
    }

    @FXML
    private void actualizar() {

        if (seleccionado == null) {
            error("Seleccioná un producto");
            return;
        }

        try {

            seleccionado.setNombre(txtNombre.getText());
            seleccionado.setPrecio(Double.parseDouble(txtPrecio.getText()));
            seleccionado.setStock(Integer.parseInt(txtStock.getText()));
            seleccionado.setIdProveedor(Integer.parseInt(txtProveedor.getText()));

            service.update(seleccionado.getIdProducto(), seleccionado);

            limpiar();
            cargar();

        } catch (Exception e) {
            error(e.getMessage());
        }
    }

    @FXML
    private void eliminar() {

        if (seleccionado == null) {
            error("Seleccioná un producto");
            return;
        }

        try {
            service.delete(seleccionado.getIdProducto());
            limpiar();
            cargar();
        } catch (Exception e) {
            error(e.getMessage());
        }
    }

    private void limpiar() {
        txtNombre.clear();
        txtPrecio.clear();
        txtStock.clear();
        txtProveedor.clear();
        seleccionado = null;
    }

    private void error(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }

    private void loadView(String fxml) {
        try {
            Parent view = FXMLLoader.load(
                    Objects.requireNonNull(getClass().getResource("/sv/elfierraso/" + fxml))
            );
            root.setCenter(view);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML public void goProductos() { loadView("productos-view.fxml"); }
    @FXML public void goVentas() { loadView("ventas-view.fxml"); }
    @FXML public void goProveedores() { loadView("proveedores-view.fxml"); }
}
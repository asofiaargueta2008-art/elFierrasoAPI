package sv.elfierraso.service;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import sv.elfierraso.model.Producto;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Servicio HTTP robusto para Productos.
 * - Usa HttpClient (Java 11+)
 * - Usa Gson para (de)serializar JSON
 * - Manejo de timeouts, retries simples y errores claros
 *
 * Ajustá BASE_URL y, si usás autenticación, setBearerToken(...)
 */
public class  ProductoService {

    private final HttpClient client;
    private final Gson gson;

    // CONFIGURABLE
    private String baseUrl = "http://localhost:5205/api/Productos";
    private Duration requestTimeout = Duration.ofSeconds(10);
    private int maxRetries = 2; // reintentos adicionales (total attempts = maxRetries + 1)
    private String bearerToken = null;

    public ProductoService() {
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();
        this.gson = new Gson();
    }

    public ProductoService(String baseUrl) {
        this();
        if (baseUrl != null && !baseUrl.isBlank()) this.baseUrl = baseUrl;
    }

    // ------------- CONFIG -------------
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public void setRequestTimeout(Duration timeout) { this.requestTimeout = timeout; }
    public void setMaxRetries(int retries) { this.maxRetries = Math.max(0, retries); }
    public void setBearerToken(String token) { this.bearerToken = token; }

    // ------------- UTIL -------------
    private HttpRequest.Builder baseBuilder(String uri) {
        HttpRequest.Builder b = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .timeout(requestTimeout)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json; charset=utf-8");
        if (bearerToken != null && !bearerToken.isBlank()) {
            b.header("Authorization", "Bearer " + bearerToken);
        }
        return b;
    }

    private String readBody(HttpResponse<String> resp) {
        String body = resp.body();
        return body == null ? "" : body;
    }

    private <T> T sendWithRetries(HttpRequest req, Type typeOfT) throws IOException, InterruptedException {
        int attempt = 0;
        IOException lastIo = null;
        while (attempt <= maxRetries) {
            try {
                HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                int code = resp.statusCode();
                String body = readBody(resp);

                if (code >= 200 && code < 300) {
                    if (typeOfT == null) return null;
                    try {
                        return gson.fromJson(body, typeOfT);
                    } catch (JsonSyntaxException ex) {
                        throw new IOException("Error parseando JSON: " + ex.getMessage() + " — body: " + body, ex);
                    }
                } else {
                    throw new IOException("HTTP " + code + " - " + body);
                }
            } catch (IOException e) {
                lastIo = e;
                // retry on IO type failures (network); for HTTP non-2xx we do not retry here
                attempt++;
                if (attempt > maxRetries) break;
                try { Thread.sleep( (long) Math.pow(2, attempt) * 200L ); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw ie; }
            }
        }
        throw lastIo != null ? lastIo : new IOException("sendWithRetries failed");
    }

    private CompletableFuture<HttpResponse<String>> sendAsyncWithRetries(HttpRequest req) {
        // simple async without exponential backoff retries (keeps implementation straightforward)
        return client.sendAsync(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }

    // ------------- API METHODS (sync) -------------

    /**
     * GET /api/Productos
     */
    public List<Producto> getAll() throws IOException, InterruptedException {
        String uri = baseUrl;
        HttpRequest req = baseBuilder(uri).GET().build();
        Type listType = TypeToken.getParameterized(List.class, Producto.class).getType();
        return sendWithRetries(req, listType);
    }

    /**
     * GET /api/Productos/{id}
     */
    public Producto getById(int id) throws IOException, InterruptedException {
        String uri = baseUrl + "/" + id;
        HttpRequest req = baseBuilder(uri).GET().build();
        return sendWithRetries(req, Producto.class);
    }

    /**
     * POST /api/Productos
     * Returns the created Producto if API returns it in body (201/200). If API returns empty body but 201/200, returns null.
     */
    public Producto create(Producto p) throws IOException, InterruptedException {
        String json = gson.toJson(p);
        HttpRequest req = baseBuilder(baseUrl)
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

        // try to parse response as Producto, but allow null if empty
        try {
            return sendWithRetries(req, Producto.class);
        } catch (IOException e) {
            // rethrow with context
            throw new IOException("Error creating product: " + e.getMessage(), e);
        }
    }

    /**
     * PUT /api/Productos/{id}
     * Uses id from p.getIdProducto()
     */
    public void update(Producto p) throws IOException, InterruptedException {
        if (p == null) throw new IllegalArgumentException("Producto null");
        update(p.getIdProducto(), p);
    }

    /**
     * PUT /api/Productos/{id}
     * Updates product with given id. Does not return entity.
     */
    public void update(int id, Producto p) throws IOException, InterruptedException {
        String json = gson.toJson(p);
        String uri = baseUrl + "/" + id;
        HttpRequest req = baseBuilder(uri)
                .PUT(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

        // use sendWithRetries with typeOfT == null to indicate we don't need body parsing
        sendWithRetries(req, null);
    }

    /**
     * DELETE /api/Productos/{id}
     */
    public void delete(int id) throws IOException, InterruptedException {
        String uri = baseUrl + "/" + id;
        HttpRequest req = baseBuilder(uri).DELETE().build();
        sendWithRetries(req, null);
    }

    // ------------- ASYNC helpers (optional) -------------

    public CompletableFuture<List<Producto>> getAllAsync() {
        String uri = baseUrl;
        HttpRequest req = baseBuilder(uri).GET().build();
        return sendAsyncWithRetries(req).thenApply(resp -> {
            int code = resp.statusCode();
            String body = readBody(resp);
            if (code >= 200 && code < 300) {
                Type listType = TypeToken.getParameterized(List.class, Producto.class).getType();
                return gson.fromJson(body, listType);
            } else {
                throw new UncheckedIOException(new IOException("HTTP " + code + " - " + body));
            }
        });
    }

    public CompletableFuture<Producto> createAsync(Producto p) {
        String json = gson.toJson(p);
        HttpRequest req = baseBuilder(baseUrl)
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();
        return sendAsyncWithRetries(req).thenApply(resp -> {
            int code = resp.statusCode();
            String body = readBody(resp);
            if (code >= 200 && code < 300 && body != null && !body.isBlank()) {
                return gson.fromJson(body, Producto.class);
            } else if (code >= 200 && code < 300) {
                return null;
            } else {
                throw new UncheckedIOException(new IOException("HTTP " + code + " - " + body));
            }
        });
    }

    public CompletableFuture<Void> updateAsync(int id, Producto p) {
        String json = gson.toJson(p);
        String uri = baseUrl + "/" + id;
        HttpRequest req = baseBuilder(uri)
                .PUT(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();
        return sendAsyncWithRetries(req).thenAccept(resp -> {
            int code = resp.statusCode();
            String body = readBody(resp);
            if (!(code >= 200 && code < 300)) {
                throw new UncheckedIOException(new IOException("HTTP " + code + " - " + body));
            }
        });
    }

    public CompletableFuture<Void> deleteAsync(int id) {
        String uri = baseUrl + "/" + id;
        HttpRequest req = baseBuilder(uri).DELETE().build();
        return sendAsyncWithRetries(req).thenAccept(resp -> {
            int code = resp.statusCode();
            String body = readBody(resp);
            if (!(code >= 200 && code < 300)) {
                throw new UncheckedIOException(new IOException("HTTP " + code + " - " + body));
            }
        });
    }
}

package sv.elfierraso.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import java.io.IOException;

public class MainController {

    @FXML
    private BorderPane contentPane;

    @FXML
    public void initialize() {
        loadView("productos-view.fxml");
    }

    @FXML
    public void irVentas() {
        loadView("ventas-view.fxml");
    }

    @FXML
    public void irProductos() {
        loadView("productos-view.fxml");
    }

    @FXML
    public void irProveedores() {
        loadView("proveedores-view.fxml");
    }


    @FXML
    private void loadView(String fxml) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/sv/elfierraso/" + fxml));
            contentPane.setCenter(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
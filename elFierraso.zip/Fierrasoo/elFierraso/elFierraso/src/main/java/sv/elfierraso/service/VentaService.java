package sv.elfierraso.service;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import sv.elfierraso.model.Ventas;

import java.io.*;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;

public class VentaService {

    private final String baseUrl = "http://localhost:5205/api/Ventas";

    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    private static final Type LIST_VENTAS = new TypeToken<List<Ventas>>() {}.getType();

    public List<Ventas> getAll() throws Exception {

        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl).openConnection();
        conn.setRequestMethod("GET");

        int code = conn.getResponseCode();

        String body = readAll(code >= 200 && code < 300
                ? conn.getInputStream()
                : conn.getErrorStream());

        if (code < 200 || code >= 300) {
            throw new RuntimeException("HTTP " + code + " -> " + body);
        }

        return gson.fromJson(body, LIST_VENTAS);
    }

    public void create(Ventas venta) throws Exception {

        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        String json = gson.toJson(venta);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        if (code != 200 && code != 201) {
            throw new RuntimeException("Error creando venta");
        }
    }

    public void update(int id, Ventas venta) throws Exception {

        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl + "/" + id).openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        String json = gson.toJson(venta);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        if (code != 200 && code != 204) {
            throw new RuntimeException("Error actualizando venta");
        }
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private static class LocalDateTimeAdapter implements JsonSerializer<LocalDateTime>, JsonDeserializer<LocalDateTime> {

        @Override
        public JsonElement serialize(LocalDateTime src, Type typeOfSrc, JsonSerializationContext context) {
            return src == null ? JsonNull.INSTANCE : new JsonPrimitive(src.toString());
        }

        @Override
        public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {

            if (json == null || json.isJsonNull()) return null;

            return LocalDateTime.parse(json.getAsString());
        }
    }
}
package sv.elfierraso.model;

public class Proveedores {

    private int idProveedor;
    private String nombre;
    private int telefono;
    private String urlImagen;
    private String email;

    public Proveedores() {}

    public int getIdProveedor() { return idProveedor; }
    public void setIdProveedor(int idProveedor) { this.idProveedor = idProveedor; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    public int getTelefono() { return telefono; }
    public void setTelefono(int telefono) {
        if (telefono <= 9999999) {
            throw new IllegalArgumentException("Teléfono inválido (mínimo 8 dígitos)");
        }
        this.telefono = telefono;
    }

    public String getUrlImagen() { return urlImagen; }
    public void setUrlImagen(String urlImagen) { this.urlImagen = urlImagen; }

    public String getEmail() { return email; }
    public void setEmail(String email) {
        String regex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]+$";
        if (email == null || !email.matches(regex)) {
            throw new IllegalArgumentException("Email inválido");
        }
        this.email = email;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
package sv.elfierraso.controller;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import sv.elfierraso.model.Producto;
import sv.elfierraso.model.Ventas;
import sv.elfierraso.service.ProductoService;
import sv.elfierraso.service.VentaService;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VentaController {

    @FXML private BorderPane root;

    @FXML private TableView<Ventas> tablaVentas;
    @FXML private TableColumn<Ventas, String> colProducto;
    @FXML private TableColumn<Ventas, Number> colCantidad;
    @FXML private TableColumn<Ventas, Number> colTotal;
    @FXML private TableColumn<Ventas, String> colFecha;

    @FXML private ComboBox<Producto> cmbProducto;
    @FXML private TextField txtCantidad;
    @FXML private TextField txtTotal;

    @FXML private ProgressIndicator loading;

    private final VentaService ventaService = new VentaService();
    private final ProductoService productoService = new ProductoService();

    private final ObservableList<Ventas> data = FXCollections.observableArrayList();
    private final Map<Integer,String> nombresProductos = new HashMap<>();

    private Ventas ventaSeleccionada = null;

    @FXML
    public void initialize() {

        configurarTabla();
        cargarProductos();
        cargarVentas();

        tablaVentas.getSelectionModel().selectedItemProperty().addListener((obs, oldV, newV) -> {
            if (newV != null) {

                ventaSeleccionada = newV;

                txtCantidad.setText(String.valueOf(newV.getCantidadVendida()));
                txtTotal.setText(String.valueOf(newV.getTotal()));

                seleccionarProductoPorId(newV.getIdProducto());
            }
        });
    }

    private void configurarTabla() {

        colProducto.setCellValueFactory(c ->
                new SimpleStringProperty(
                        nombresProductos.getOrDefault(c.getValue().getIdProducto(),"Producto")
                ));

        colCantidad.setCellValueFactory(c ->
                new SimpleIntegerProperty(c.getValue().getCantidadVendida()));

        colTotal.setCellValueFactory(c ->
                new SimpleDoubleProperty(c.getValue().getTotal()));

        colFecha.setCellValueFactory(c ->
                new SimpleStringProperty(c.getValue().getFecha().toString()));

        tablaVentas.setItems(data);
    }

    private void cargarProductos() {

        Task<List<Producto>> task = new Task<>() {
            @Override
            protected List<Producto> call() throws Exception {
                return productoService.getAll();
            }
        };

        task.setOnSucceeded(e -> {

            ObservableList<Producto> productos =
                    FXCollections.observableArrayList(task.getValue());

            cmbProducto.setItems(productos);

            cmbProducto.setCellFactory(cb -> new ListCell<>() {
                @Override
                protected void updateItem(Producto item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNombre());
                }
            });

            cmbProducto.setButtonCell(new ListCell<>() {
                @Override
                protected void updateItem(Producto item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getNombre());
                }
            });

            for (Producto p : productos) {
                nombresProductos.put(p.getIdProducto(), p.getNombre());
            }

            tablaVentas.refresh();
        });

        new Thread(task).start();
    }

    private void cargarVentas() {

        loading.setVisible(true);

        Task<List<Ventas>> task = new Task<>() {
            @Override
            protected List<Ventas> call() throws Exception {
                return ventaService.getAll();
            }
        };

        task.setOnSucceeded(e -> {
            data.setAll(task.getValue());
            loading.setVisible(false);
        });

        task.setOnFailed(e -> {
            loading.setVisible(false);
            showError("Error cargando ventas");
        });

        new Thread(task).start();
    }

    private void seleccionarProductoPorId(int idProducto) {
        for (Producto p : cmbProducto.getItems()) {
            if (p.getIdProducto() == idProducto) {
                cmbProducto.setValue(p);
                break;
            }
        }
    }

    @FXML
    public void onAgregar() {

        Producto producto = cmbProducto.getValue();

        if (producto == null) {
            showError("Selecciona un producto");
            return;
        }

        try {

            Ventas v = new Ventas();
            v.setIdProducto(producto.getIdProducto());
            v.setCantidadVendida(Integer.parseInt(txtCantidad.getText()));
            v.setTotal(Double.parseDouble(txtTotal.getText()));
            v.setFecha(LocalDateTime.now());

            loading.setVisible(true);

            Task<Void> task = new Task<>() {
                @Override
                protected Void call() throws Exception {
                    ventaService.create(v);
                    return null;
                }
            };

            task.setOnSucceeded(e -> {
                loading.setVisible(false);
                limpiarFormulario();
                cargarVentas();
                showInfo("Venta creada");
            });

            new Thread(task).start();

        } catch (Exception ex) {
            showError("Datos inválidos");
        }
    }

    @FXML
    public void onRefresh() {
        cargarVentas();
    }

    private void limpiarFormulario() {
        cmbProducto.setValue(null);
        txtCantidad.clear();
        txtTotal.clear();
        ventaSeleccionada = null;
    }

    private void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }

    private void showInfo(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
}
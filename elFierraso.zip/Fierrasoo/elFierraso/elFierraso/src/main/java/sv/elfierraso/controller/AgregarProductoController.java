package sv.elfierraso.controller;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sv.elfierraso.model.Producto;
import sv.elfierraso.service.ProductoService;

import java.util.function.Consumer;

public class AgregarProductoController {

    @FXML private TextField txtNombre;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtStock;
    @FXML private TextField txtUrlImagen;
    @FXML private TextField txtIdProveedor;
    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;
    @FXML private ProgressIndicator loading;

    private final ProductoService service = new ProductoService();
    private Producto productoEditar; // si es null -> crear
    private Consumer<Void> onSaved; // callback

    @FXML
    public void initialize() {
        loading.setVisible(false);
        btnGuardar.setOnAction(e -> guardar());
        btnCancelar.setOnAction(e -> cerrar());
    }

    public void setProducto(Producto p) {
        this.productoEditar = p;
        // poblar campos
        txtNombre.setText(p.getNombre());
        txtPrecio.setText(String.valueOf(p.getPrecio()));
        txtStock.setText(String.valueOf(p.getStock()));
        txtUrlImagen.setText(p.getUrlImagen());
        txtIdProveedor.setText(String.valueOf(p.getIdProveedor()));
    }

    public void setOnSaved(Runnable callback) {
        this.onSaved = v -> callback.run();
    }

    private void guardar() {
        String nombre = txtNombre.getText();
        String sPrecio = txtPrecio.getText();
        String sStock = txtStock.getText();
        String urlImg = txtUrlImagen.getText();
        String sIdProv = txtIdProveedor.getText();

        double precio;
        int stock;
        int idProv;

        try {
            precio = Double.parseDouble(sPrecio);
            stock = Integer.parseInt(sStock);
            idProv = Integer.parseInt(sIdProv);
        } catch (NumberFormatException ex) {
            showError("Precio, stock o idProveedor inválido.");
            return;
        }

        if (nombre == null || nombre.isBlank()) {
            showError("El nombre es obligatorio.");
            return;
        }

        Producto p = (productoEditar == null) ? new Producto() : productoEditar;
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setUrlImagen(urlImg);
        p.setIdProveedor(idProv);

        loading.setVisible(true);
        Task<Void> task = new Task<>() {
            @Override
            protected Void call() throws Exception {
                if (productoEditar == null) {
                    service.create(p);
                } else {
                    service.update(p);
                }
                return null;
            }
        };

        task.setOnSucceeded(e -> {
            loading.setVisible(false);
            Platform.runLater(() -> {
                showInfo(productoEditar == null ? "Producto creado." : "Producto actualizado.");
                if (onSaved != null) onSaved.accept(null);
                cerrar();
            });
        });

        task.setOnFailed(e -> {
            loading.setVisible(false);
            Platform.runLater(() -> showError("Error al guardar: " + task.getException().getMessage()));
        });

        new Thread(task).start();
    }

    private void cerrar() {
        Stage s = (Stage) btnCancelar.getScene().getWindow();
        s.close();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.showAndWait();
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.showAndWait();
    }
}
